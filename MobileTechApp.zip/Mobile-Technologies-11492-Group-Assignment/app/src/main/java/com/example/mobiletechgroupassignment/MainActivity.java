package com.example.mobiletechgroupassignment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void openBarcodeReader(View view) {
        Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
        intent.putExtra("reader", "Barcode Reader");
        startActivity(intent);
    }

    public void openContentReader(View view) {
        Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
        intent.putExtra("reader", "Content Reader");
        startActivity(intent);
    }

    public void openTextReader(View view) {
        Intent intent = new Intent(MainActivity.this, MLKitActivity.class);
        intent.putExtra("reader", "Text Reader");
        startActivity(intent);
    }

    public void openListView(View view) {
        Intent intent = new Intent(MainActivity.this, ListViewActivity.class);
        startActivity(intent);
    }
}